package com.niit.springwithhibernate.dao;

import java.sql.Connection;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.niit.springwithhibernate.model.Customer;

public class SbiImpl implements SBI
{
	static Connection con=null;
	SessionFactory sf=null;
	public SbiImpl()
	{
		Configuration cfg=new Configuration().configure().addAnnotatedClass(Customer.class);
		sf=cfg.buildSessionFactory();
	}

	public boolean addaccount(Customer cus) 
	{
		boolean b=false;
		Session ses=sf.openSession();
		Transaction tx=ses.beginTransaction();
		Object obj=ses.save(cus);
		if(obj!=null)
		{
			b=true;
		}
		tx.commit();
		sf.close();
		return b;
	}

	@Override
	public boolean validation(Customer cus) 
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deposit(Customer cus) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean withdraw(Customer cus) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer balanceenquiry(Customer cus) {
		// TODO Auto-generated method stub
		return null;
	}
	
}

package com.niit.springwithhibernate.dao;

import com.niit.springwithhibernate.model.Customer;

public interface SBI 
{
	public boolean addaccount(Customer cus);
	public boolean validation(Customer cus);
	public boolean deposit(Customer cus);
	public boolean withdraw(Customer cus);
	public Customer balanceenquiry(Customer cus); 
	
}

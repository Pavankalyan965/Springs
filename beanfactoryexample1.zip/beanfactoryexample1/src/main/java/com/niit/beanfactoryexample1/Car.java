package com.niit.beanfactoryexample1;

public class Car 
{
	public void move()
	{
		System.out.println("this is car object");
	}

}

package com.niit.beanfactoryexample1;

public class Emp 
{

}

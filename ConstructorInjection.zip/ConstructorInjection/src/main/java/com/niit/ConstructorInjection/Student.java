package com.niit.ConstructorInjection;

public class Student
{
	private String name;
	private int marks;
	public Student(String name,int marks)
	{
		super();
		this.name=name;
		this.marks=marks;
		
	}
	@Override
	public String toString()
	{
		return "Student[name="+name+",marks="+marks+"]";
	}
}

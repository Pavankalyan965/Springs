package com.niit.springexample2;

import org.springframework.stereotype.Component;

@Component
public class Car implements Vehicle 
{
	public void move()
	{
		System.out.println("This is move method of car class");
	}
}

package com.niit.springexample2;

public interface Vehicle
{
	void move();
}

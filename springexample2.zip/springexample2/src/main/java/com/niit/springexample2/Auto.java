package com.niit.springexample2;

import org.springframework.stereotype.Component;

@Component
public class Auto implements Vehicle
{
	public void move()
	{
		System.out.println("this is move method of Auto class");
	}
}

package com.niit.ApplicationContextExample;

import org.springframework.beans.factory.BeanNameAware;

public class Student implements BeanNameAware 
{

	private String name;
	private int marks;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	@Override
	public String toString()
	{
		return "Student[name="+name+",marks="+marks+"]";
	}
	public void setBeanName(String name)
	{
		System.out.println("bean name:"+name);
	}
}

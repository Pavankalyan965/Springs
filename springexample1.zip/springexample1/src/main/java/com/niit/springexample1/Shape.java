package com.niit.springexample1;

public interface Shape 
{
	void draw();
}
